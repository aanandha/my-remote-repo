package com.flp.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.flp.ems.domain.Employee;
import com.flp.ems.util.Validate;
public class EmployeeDaoImplForDB implements IemployeeDao {
	Connection con;
	Statement stmt;
	PreparedStatement ps;
	ResultSet rs;
	String query,res;
	int i;
	Scanner in=new Scanner(System.in);
	boolean a;
	
	
public EmployeeDaoImplForDB()
{
	
	try {
	     Class.forName("com.mysql.jdbc.Driver");
	     con = DriverManager.getConnection ("jdbc:mysql://localhost:3306/test");
	  
	    }
	catch (SQLException e) {
	    e.printStackTrace();
	}
	catch (Exception e) {
	    e.printStackTrace();
	}
	
}

	@Override
	public void AddEmployee(Employee emp)  {
	 query="INSERT INTO Employee(Name,Kinid,EMailid,PhoneNo,DOB,DOJ,Address,Deptid,Projectid,Roleid) Values(?,?,?,?,?,?,?,?,?,?)";            
		try
		{
	    ps=con.prepareStatement(query);
		ps.setString(1,emp.getName());
		
		ps.setString(2, emp.getKinid());
		
		ps.setString(3, emp.getEMailid());
		
		ps.setString(4, emp.getPhoneNo());
		
		ps.setString(5, emp.getDOB());
		
		ps.setString(6, emp.getDOJ());
		
		ps.setString(7, emp.getAddress());
		
		ps.setInt(8, emp.getdeptid());
		
		ps.setInt(9, emp.getProjectid());
		ps.setInt(10, emp.getRoleid());
        i=ps.executeUpdate();
		System.out.println(i+" Employee added"); 
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	@Override
	public void ModifyEmployee(Employee emp) {
		System.out.println("select which one you want to modify");
	    System.out.println("1. name\n2.PhoneNo\n3. Address\n4.Emailid");
    int choice=in.nextInt();
	switch(choice)
	{
	case 1:
		System.out.println("Enter the name: ");
	    res=in.next();
	    a= Validate.validatename(res);
	    if(a){
	    	try
	    	{
	    	ps=con.prepareStatement("update employee set name=? where Kinid=? or name=? or EMailid=?");
	    	ps.setString(1, res);
	    	ps.setString(2, emp.getKinid());
	    	ps.setString(3, emp.getName());
	    	ps.setString(4, emp.getEMailid());
	    	}catch(Exception e)
	    	{
	    		System.out.println(e);
	    	}
	       
	    }
	    else{
	    	System.out.println("name should not be empty"); 
	    	return; 
	    }
		break;
	case 2:
		System.out.println("Enter the PhoneNo: ");
		 res=in.next();
	   a= Validate.validatePhoneNumber(res);
	   if(a){
		   try
		   {
			ps=con.prepareStatement("update employee set PhoneNo=? where Kinid=? or name=? or EMailid=?");
	    	ps.setString(1, res);
	    	ps.setString(2, emp.getKinid());
	    	ps.setString(3, emp.getName());
	    	ps.setString(4, emp.getEMailid());
		   }catch(Exception e)
	    	{
	    		System.out.println(e);
	    	}
		    
	   }
	   else {
		   System.out.println("invalid phonenumber");
		   return;
	   }
	   break;
	case 3:
		System.out.println("Enter the Address: ");
		 res=in.next();
		 try{
			 ps=con.prepareStatement("update employee set Address=? where Kinid=? or name=? or EMailid=?");
	    	ps.setString(1, res);
	    	ps.setString(2, emp.getKinid());
	    	ps.setString(3, emp.getName());
	    	ps.setString(4, emp.getEMailid());
	    	}catch(Exception e)
	    	{
	    		System.out.println(e);
	    	}
		 break;
	case 4:
		System.out.println("Enter the EMailid");
		 res=in.next();
	 a=Validate.validateEmailAddress(res);
	if(a){
		try {
			ps=con.prepareStatement("update employee set EMailid=? where Kinid=? or name=? or EMailid=?");
	    	ps.setString(1, res);
	    	ps.setString(2, emp.getKinid());
	    	ps.setString(3, emp.getName());
	    	ps.setString(4, emp.getEMailid());
		}catch(Exception e)
    	{
    		System.out.println(e);
    	}
	}
	else
	{
		System.out.println("invalid emailid");
	    return;
	}
		break;
	default:
		System.out.println("InValid option! try again");
		this.ModifyEmployee(emp);
		break;
	}
    try {
	 i=ps.executeUpdate();  
 	 System.out.println(i+" records updated");  
    }catch(Exception e)
	{
		System.out.println(e);
	}
	 this.getAllEmployee();
 
	System.out.println("Do you want to still modify details (yes/no)");
	String ans=in.next();
    	
	if(ans.equals("yes"))
	{
		this.ModifyEmployee(emp);
	}
	else
		return;
  }
		
		


	@Override
	public void RemoveEmployee(String employeeid) {
		   query="delete from employee where employeeid=? or Kinid=?";
		try
		{
			ps=con.prepareStatement(query); 
			ps.setString(1, employeeid);
			ps.setString(2, employeeid);
		    i=ps.executeUpdate();
			System.out.println(i+" records deleted Successfully");
			
		 }
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public void SearchEmployee(String Kinid) {
		query="select * from employee where Kinid=? or EMailid=? or Name=?";
		try
		{
			
		    ps=con.prepareStatement(query);
		    ps.setString(1,Kinid);
		    ps.setString(2,Kinid);
		    ps.setString(3,Kinid);
					  rs=ps.executeQuery(); 
					  while(rs.next()){
					    System.out.println("Employeeid\tName\tKinid\tEMailid\tPhoneNo\tDOB\tDOJ\tAddress\tDeptid\tProjectid\tRoleid");
					    System.out.println(rs.getString(1)+"\t\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getInt(9)+"\t"+rs.getInt(10)+"\t"+rs.getInt(11));  
						System.out.println("Employee Searched Successfully");
						return;
					  }
		   System.out.println("Employee not available"); 
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public void getAllEmployee() {
		query="select employeeid,name,kinid,Emailid,DeptName,Projectname,Rolename from employee inner join department on employee.deptid=department.deptid inner join Project on employee.projectid=project.projectid inner join Role on employee.roleid=role.roleid";
		try
		{
		ps=con.prepareStatement(query);  
	    rs=ps.executeQuery(); 
	    System.out.println("Employeeid\tName\t\tKinid\tEMailid\tDeptname\tProjectname\tRolename");
		while(rs.next()){ 
		System.out.println(rs.getString(1)+"\t\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\t"+rs.getString(7));  
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	

}
