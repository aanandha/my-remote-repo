package com.flp.ems.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.flp.ems.domain.Employee;
import com.flp.ems.service.EmployeeServiceImpl;
import com.flp.ems.util.Validate;

public class EmployeeDaoImplForList implements IemployeeDao {
	public static List<Employee> list=new ArrayList<Employee>();
	
	Iterator<Employee> itr;
	Scanner in=new Scanner(System.in);
	Employee e;
	boolean a;
	
	@Override
	public void AddEmployee(Employee emp)
	{
		list.add(emp);
		System.out.println("employee added to list");
	}
	@Override
	public void ModifyEmployee(Employee emp)
	{ 
		String res;
           itr = list.iterator();
		    while(itr.hasNext()){
		    	Employee e=(Employee) itr.next();
		    	if(e.getKinid().equals(emp.getKinid())||e.getEMailid().equals(emp.getEMailid())||e.getName().equalsIgnoreCase(emp.getName())){

					
		    	System.out.println("select which one you want to modify");
			    System.out.println("1. name\n2.PhoneNo\n3. Address\n4.Emailid");
		    int choice=in.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter the name: ");
			    res=in.next();
			    a= Validate.validatename(res);
			    if(a){
			    	emp.setName(res);
			    }
			    else{
			    	System.out.println("name should not be empty"); 
			    	return; 
			    }
				break;
			case 2:
				System.out.println("Enter the PhoneNo: ");
				 res=in.next();
			   a= Validate.validatePhoneNumber(res);
			   if(a){
				    emp.setPhoneNo(res);
			   }
			   else {
				   System.out.println("invalid phonenumber");
				   return;
			   }
			   break;
			case 3:
				System.out.println("Enter the Address: ");
				 res=in.next();
				emp.setAddress(res);
				break;
			case 4:
				System.out.println("Enter the EMailid");
				 res=in.next();
			 a=Validate.validateEmailAddress(res);
			if(a){
				emp.setEMailid(res);
			}
			else
			{
				System.out.println("invalid emailid");
			    return;
			}
				break;
			default:
				System.out.println("InValid option! try again");
				this.ModifyEmployee(emp);
				break;
			}
		
			System.out.println("Employee Modified Successfully");
	    	this.getAllEmployee();
		 
	    	System.out.println("Do you want to still modify details (yes/no)");
	    	String ans=in.next();
		    	
	    	if(ans.equals("yes"))
	    	{
	    		this.ModifyEmployee(emp);
	    	}
	    	else
	    		return;
		  }
	    }
}
	
	@Override
	public void SearchEmployee(String Kinid)
	{
	     Iterator itr = list.iterator();
	    while(itr.hasNext()){
			Employee emp=(Employee) itr.next();
			if(emp.getKinid().equals(Kinid)||emp.getEMailid().equals(Kinid)||emp.getName().equalsIgnoreCase(Kinid)){
				System.out.println("Employeeid\tName\tKinid\tEMailid\tPhone\tAddress\tDepartment\tProject\tRole");
				System.out.println(emp);
		         System.out.println("Employee Successfully Searched");
				return;
			}
		}
		System.out.println("Employee not available");
	
	}
	
	@Override
	public void RemoveEmployee(String employeeid)
	{
		itr = list.iterator();
		System.out.println("Do you want to remove employee?(yes/no)");
		String choice=in.next();
		if(choice.equals("yes"))
		{
			while(itr.hasNext()){
					e=(Employee)itr.next();
				if((e.getemployeeid()==Integer.parseInt(employeeid))||(e.getKinid().equals(employeeid))){
					itr.remove();
					EmployeeServiceImpl.khs.remove(e.getKinid());
					EmployeeServiceImpl.ehs.remove(e.getEMailid());
					
					System.out.println("Employee Successfully removed");
					return;
				}
			}
		}
		System.out.println("Employee not available");
	}
	
	@Override
	public void getAllEmployee()
	{
		itr = list.iterator();
		
		System.out.println("Employeeid\tName\tKinid\tEMailid\t\tPhone\t\tAddress\tDepartment\tProject\tRole");
		while(itr.hasNext()){
			System.out.println(itr.next());
	        } 
	}

}
