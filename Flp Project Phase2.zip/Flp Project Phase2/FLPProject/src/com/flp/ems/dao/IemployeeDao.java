package com.flp.ems.dao;

import java.sql.SQLException;

import com.flp.ems.domain.Employee;

public interface IemployeeDao {
	public void AddEmployee(Employee emp);
    public void ModifyEmployee(Employee emp);
    public void RemoveEmployee(String employeeid);
    public void SearchEmployee(String Kinid);
    public void getAllEmployee();
    

}
