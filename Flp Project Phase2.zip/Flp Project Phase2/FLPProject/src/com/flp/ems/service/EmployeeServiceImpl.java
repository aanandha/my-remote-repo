package com.flp.ems.service;

import java.sql.SQLException;
//import java.util.Date;
import java.util.HashMap;

import java.util.HashSet;
import java.util.Set;

import com.flp.ems.dao.EmployeeDaoImplForDB;
import com.flp.ems.dao.EmployeeDaoImplForList;
import com.flp.ems.dao.IemployeeDao;
import  com.flp.ems.domain.Employee;
import com.flp.ems.util.Validate;
public  class EmployeeServiceImpl implements IEmployeeService{
//	 IemployeeDao edi=new EmployeeDaoImplForList ();
	EmployeeDaoImplForDB edi=new EmployeeDaoImplForDB ();
	public static Set<String> khs=new HashSet<String>();
	public static Set<String> ehs=new HashSet<String>();
	Employee emp=new Employee();
	
 public void AddEmployee(HashMap hm) 
	 {
		 
		 emp.setName((String) hm.get("Name"));
		 emp.setKinid(String.valueOf(hm.get("Kinid")));
		 emp.setEMailid((String) hm.get("EMailid"));
		 emp.setPhoneNo((String) hm.get("PhoneNo"));
		 emp.setDOB((String) hm.get("DOB"));
		 emp.setDOJ((String) hm.get("DOJ"));
		 emp.setAddress((String) hm.get("Address"));
		 emp.setDepartment((String) hm.get("Department"));
		 emp.setdeptid((int) hm.get("deptid"));
		 emp.setProjectname((String) hm.get("Projectname"));
		 emp.setProjectdesc((String) hm.get("Projectdesc"));
		 emp.setProjectid((int) hm.get("Projectid"));
		 emp.setRole((String) hm.get("Role"));
		 emp.setRoleid((int) hm.get("Roleid"));
		 boolean F3,F4,F5;
	        F3= Validate.validateEmailAddress(emp.getEMailid());
	        F4=Validate.validatePhoneNumber(emp.getPhoneNo());
	        F5=Validate.validatename(emp.getName());
	        if(F3 && F4 && F5)
	        {

	        	if(khs.contains(emp.getKinid()))
				{
	        		System.out.println("Kinid already exist");
	        		return;
	        	
				}
				if(ehs.contains(emp.getEMailid()))
				{
					System.out.println("Emailid already exist");
					return;
				}
				khs.add(emp.getKinid());

				ehs.add(String.valueOf(emp.getEMailid()));

				edi.AddEmployee(emp);
			}
			else
			{
				System.out.println("EMailid,PhoneNo,Name validation fails\n Employee not added to list");
			
			}
	  }
public void ModifyEmployee(String Kinid)
	 {
		
		emp.setKinid(Kinid);
		emp.setName(Kinid);
		emp.setEMailid(Kinid);
		edi.ModifyEmployee(emp);
	 }
public void RemoveEmployee(String employeeid)
	{
	 edi.RemoveEmployee(employeeid);
	}
   public void SearchEmployee(String Kinid,String Name,String EMailid)
    { 
    	if((!Kinid.equals("@"))&&(!Name.equals("@"))&&(!EMailid.equals("@"))){
			edi.SearchEmployee(Kinid);
		}
		else if((!Kinid.equals("@"))&&(!EMailid.equals("@"))){
			edi.SearchEmployee(Kinid);
		}
		else if((!Name.equals("@"))&&(!EMailid.equals("@"))){
			edi.SearchEmployee(EMailid);
		}
		else if((!Kinid.equals("@"))&&(!Name.equals("@"))){
			edi.SearchEmployee(Kinid);
		}
		else if((!Kinid.equals("@"))){
			edi.SearchEmployee(Kinid);
		}
		else if((!Name.equals("@"))){
			edi.SearchEmployee(Name);
		}
		else if((!EMailid.equals("@"))){
			edi.SearchEmployee(EMailid);
		}
	}
public void getAllEmployee()
    {
    	edi.getAllEmployee();
    }
    
}
