package com.flp.ems.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Validate {
private static Pattern emailNamePtrn = Pattern.compile(
		    "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		     
		    public static boolean validateEmailAddress(String EMailid){
		         
		        Matcher mtch = emailNamePtrn.matcher(EMailid);
		        if(mtch.matches()){
		            return true;
		        }
		        return false;
		    }
    		
    		public static boolean validatePhoneNumber(String PhoneNo) {
    	        
    	        if (PhoneNo.matches("\\d{10}")) return true;    	   
    	        else return false;
    	         
    	    }
    		 private static Pattern dateFrmtPtrn =
    		            Pattern.compile("(?:(?:[12][0-9]|0?[1-9])/0?2|(?:30|[12][0-9]|0?[1-9])/(?:0?[469]|11)|(?:3[01]|[12][0-9]|0?[1-9])/(?:0?[13578]|1[02]))/[0-9]{4}$");
    		     
    		    public static boolean validateDateFormat(String dob){
    		         
    		        Matcher mtch = dateFrmtPtrn.matcher(dob);
    		        if(mtch.matches()){
    		        	
    		            return true;
    		            
    		        }
    		        
    		        return false;
    		    }
    		    public static boolean validatename(String Name){
    		        String pattern="";
    		            if(Name.matches(pattern)){
    		                return false;
    		            }
    		            return true;   
    		    }
    		
}

